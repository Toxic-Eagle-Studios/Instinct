# INSTINCT — Shared Brain AI Expansion & Unified "While You're At It" Hub

Expand INSTINCT's Gemini-powered Shared Brain with four new proactive AI capabilities—Smart Memory Synthesis & Daily Briefing, Streaming AI Follow-Up Chat, AI Auto-Tagging & Smart Category Organization, and Proactive Errand/Shopping Checklist Generation—paired with a unified **"While You're At It"** contextual hub that bundles active reminders, saved preferences, and past fixes into a single interactive checklist whenever the user starts an errand, visits a place, or contacts someone.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> All core product decisions were confirmed during Phase 1 and are incorporated into this plan:

- **Confirmed Decision 1 — Full Suite of 4 New AI Capabilities**:
  1. **Smart Memory Synthesis & Daily Briefing Digest**: AI synthesizes stored reminders, preferences, and recent fixes into an actionable daily briefing card with priority highlights.
  2. **Streaming AI Follow-Up Chat on Memories & Fixes**: Users can ask follow-up questions in real time (using `generateContentStream()` for low-latency token streaming) directly from any AI result, active repair session, or stored memory.
  3. **AI Auto-Tagging & Smart Category Organization**: Gemini automatically infers and applies semantic tags and canonical categories (`Personal`, `Work`, `Shopping`, `Home`, `Food & Drinks`, `Health`, `Tech`, `Finance`) to newly created or unorganized memories, with a one-tap **"AI Auto-Organize"** action.
  4. **Proactive AI Errand & Shopping Checklist Generator**: Given any destination or activity (e.g., *"Heading to Costco"*, *"Weekend home maintenance"*, *"Packing for work trip"*), Gemini cross-references the user's saved memories and generates a ready-to-check errand list.
- **Confirmed Decision 2 — Unified "While You're At It" Hub**:
  - Combines smart activity/location chains, one-tap active context pills (e.g., *Grocery Run*, *Hardware Store*, *Coffee Shop*, *Calling Family*, *Leaving Work*, *At Home*), and AI-suggested companion tasks in both the Home screen and the dedicated **While You're At It** tab.
- **Confirmed Decision 3 — Interactive Cross-Memory Checklist**:
  - Triggering a context surfaces a unified interactive checklist that groups **Active Reminders (While You're At It)**, **Matched Preferences (Exactly)**, **Relevant Past Fixes (Undo IRL)**, and **AI-Suggested Bonus Tasks** so the user can check items off, copy exact preferences, or save AI suggestions in one place.

---

## 1. Overview & Core Concept

- **What It Does**:
  - Elevates INSTINCT from a passive memory store into an active, context-aware daily companion powered by Firebase AI Logic (`gemini-3.8-flash`).
  - Bridges the three pillars of the Shared Brain (**While You're At It**, **Undo IRL**, and **Exactly**) so that starting any real-world activity immediately brings together everything the user needs to do, how they prefer it done, and solutions that worked in the past.
- **Target Audience / Persona**:
  - Busy individuals who want a single intelligent "second brain" that remembers errands, exact personal specifications, and practical troubleshooting steps without manual folder management.
- **Key Value**:
  - Eliminates forgotten errands when already at a store or talking to someone, provides instant streaming conversational follow-ups when troubleshooting, and keeps every memory automatically tagged and categorized.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **AI Hub & Daily Briefing (Home Screen)**:
     - Below the Universal Input Card, an interactive **Shared Brain AI Command Strip** offers one-tap triggers for **Daily Briefing Synthesis**, **Errand Checklist Generator**, **AI Auto-Organize**, and **Streaming Follow-Up Chat**.
     - Tapping **Daily Briefing** synthesizes all active reminders, top preferences, and recent verified fixes into a structured executive summary with suggested next actions.
  2. **Streaming AI Follow-Up Chat**:
     - Whenever Gemini responds to an input or during an active repair/memory view, users can type or speak a follow-up question in the **Streaming AI Follow-Up Drawer**. Tokens stream live onto the screen as Gemini generates the answer, with a button to save the insight directly as a MemoryEntry.
  3. **AI Auto-Tagging & Smart Category Organization**:
     - When saving a new memory—or tapping **Auto-Organize Memories**—Gemini inspects the content, assigns the best-fit category and 2–4 semantic tags, and persists the updated metadata to Room and Firestore.
  4. **Unified "While You're At It" Hub & Interactive Checklist**:
     - Users can activate a context either by typing/speaking in the Universal Input (e.g., *"I'm at Walmart"*) or by tapping a **Quick Context Mode Pill** (*Grocery / Store*, *Coffee / Food*, *Hardware / DIY*, *Work / Office*, *Call / Family*, *Home Routine*) on the Home screen or the **While You're At It** tab.
     - Activating a context opens the **Interactive "While You're At It" Checklist Card**, featuring:
       - **Progress Header**: Context badge, completion counter (e.g., `2 of 4 completed`), and a button to **Generate AI Companion Tasks** for that context.
       - **Checkable Reminders**: Tap to mark done (`Noted` for recurring reminders, `Done` for one-time tasks) or snooze.
       - **Linked Preferences ("Exactly")**: Inline reference cards (e.g., preferred brand, coffee order, clothing size, or measurements) with one-tap copy.
       - **Linked Fixes ("Undo IRL")**: Relevant verified repair notes or tools needed if the errand involves hardware/DIY.
       - **AI-Suggested "While You're At It" Add-Ons**: Smart companion items suggested by Gemini based on the active context and past habits, which can be checked off or saved to Room with one tap.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Dark cinematic tactical utility ("Toxic Eagle" high-contrast dark UI) with crisp neon telemetry accents and zero visual clutter.
  - *Color Palette & Mood*:
    - `--background`: Deep Jet Black (`#0A0B0E`) and Dark Charcoal (`#12151B`)
    - `--card` / `--surface`: Graphite Card (`#181C24`) and Graphite Surface (`#1F2430`) with `1.dp` Graphite Borders (`#2B3242`)
    - `--primary` (While You're At It / Reminders): Electric Lime (`#C6FF00`)
    - `--accent` (AI Synthesis & Exactly Preferences): Cyan Electric (`#00E5FF`)
    - `--secondary` (Undo IRL Fixes): Toxic Green Glow (`#00FF66`)
    - `--destructive` (Warnings / Hazard Alerts): Deep Red Warning (`#FF3B30`)
  - *Typography & Hierarchy*: Bold uppercase section headers with `0.8.sp–1.5.sp` letter spacing, high-legibility `14.sp–16.sp` primary task titles, and `11.sp–12.sp` metadata badges.
  - *Interactive Feedback & Motion*: Smooth `AnimatedVisibility` expansions for the AI Briefing, Streaming Chat panel, and Interactive Context Checklist, plus animated progress bars as checklist items are completed.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Hybrid Local + Gemini Context Matching for "While You're At It"**
  - *Chosen Approach*: Combine instant on-device semantic/keyword graph matching across `Reminder`, `Preference`, and `FixHistory` entries with Gemini (`gemini-3.8-flash`) structured inference for companion task suggestions and errand checklist generation.
  - *Why*: Local graph matching guarantees zero-latency context activation even offline, while Gemini enriches the active context with intelligent cross-memory connections and proactive errand suggestions.
  - *Alternatives Considered*: Pure cloud-only context triggering was rejected because users checking their list inside a store with spotty reception need instant responsiveness.

- **Decision 2: Real-Time Token Streaming (`generateContentStream`) for Follow-Up Chat**
  - *Chosen Approach*: Use Firebase AI Logic's `generateContentStream()` with a 60-second coroutine timeout window and conversation history context for follow-up questions.
  - *Why*: Slashes perceived Time-to-First-Token to ~1 second when asking follow-up questions about a repair step, a recipe preference, or an errand plan.
  - *Alternatives Considered*: Unary blocking calls were passed over for conversational follow-ups because waiting for full generation feels sluggish during multi-turn Q&A.

- **Decision 3: Structured JSON Schema (`Schema.obj`) for AI Briefing, Auto-Tagging & Errand Checklists**
  - *Chosen Approach*: Configure dedicated `generationConfig` with `responseMimeType = "application/json"` and `Schema.obj(...)` definitions for the Daily Briefing, Smart Auto-Tagger, and Errand Checklist Generator, backed by deterministic local synthesis if the device is offline.
  - *Why*: Ensures reliable, type-safe parsing directly into Compose UI state without brittle markdown stripping.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```
┌────────────────────────────────────────────────────────────────────────────┐
│                        JETPACK COMPOSE UI LAYER                            │
│                                                                            │
│  ┌──────────────────────────────┐    ┌──────────────────────────────────┐  │
│  │         HomeScreen           │    │     RemindersScreen (Hub)        │  │
│  │  • UniversalInputCard        │    │  • Quick Context Mode Switcher   │  │
│  │  • SharedBrainAiHubCard      │    │  • Active Context Checklist Card │  │
│  │    - Daily Briefing Digest   │    │  • Chained Reminders & Prefs     │  │
│  │    - Errand List Generator   │    │  • AI Companion Task Suggestions │  │
│  │    - AI Auto-Organize        │    └─────────────────┬────────────────┘  │
│  │    - Streaming Follow-Up Chat│                      │                   │
│  │  • WhileYoureAtItChecklist   │                      │                   │
│  └──────────────┬───────────────┘                      │                   │
└─────────────────┼──────────────────────────────────────┼───────────────────┘
                  │                                      │
                  ▼                                      ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                     STATE & PRESENTATION (InstinctViewModel)               │
│                                                                            │
│  • activeContextSession: StateFlow<WhileYoureAtItSession?>                 │
│  • aiBriefingState: StateFlow<AiBriefingUiState>                           │
│  • streamingChatState: StateFlow<StreamingChatUiState>                     │
│  • errandChecklistState: StateFlow<ErrandChecklistUiState>                 │
│  • isAutoOrganizing: StateFlow<Boolean>                                    │
└─────────────────┬──────────────────────────────────────┬───────────────────┘
                  │                                      │
                  ▼                                      ▼
┌─────────────────────────────────────┐  ┌───────────────────────────────────┐
│   AI ENGINE (InstinctAiService)     │  │ SINGLE SOURCE OF TRUTH REPOSITORY │
│                                     │  │   (MemoryRepository / Room DAO)   │
│  • Firebase.ai ("gemini-3.8-flash") │  │                                   │
│  • processUniversalInput()          │  │  • MemoryEntry Sealed Hierarchy:  │
│  • generateDailyBriefing()          │  │    - MemoryEntry.Reminder         │
│  • streamFollowUpChat()             │  │    - MemoryEntry.Preference       │
│  • autoTagAndCategorizeMemories()   │  │    - MemoryEntry.FixHistory       │
│  • generateErrandChecklist()        │  │  • Local Room DB + Firestore Sync │
└─────────────────────────────────────┘  └───────────────────────────────────┘
```

### Data Model & State

- **`WhileYoureAtItSession` (Active Context Bundle)**:
  - `contextLabel: String` (e.g., `"Walmart / Grocery Run"`, `"Calling Dad"`, `"Hardware Store"`)
  - `matchedReminders: List<Reminder>` (checkable reminders tied to this activity/place/person)
  - `completedReminderIds: Set<String>` (tracks in-session checklist progress)
  - `matchedPreferences: List<Preference>` (relevant saved preferences from *Exactly*, such as brands, orders, or sizes)
  - `matchedFixes: List<Fix>` (relevant verified solutions or `toolsNeeded` from *Undo IRL*)
  - `aiSuggestedTasks: List<SuggestedCompanionTask>` (proactive companion tasks generated by Gemini or context heuristics, each with a `checked` state and one-tap **Save to Room** action)
- **`DailyBriefingDigest`**:
  - `headline: String`, `summary: String`, `priorityReminders: List<String>`, `insightTip: String`, `categoryBreakdown: Map<String, Int>`, `generatedAt: Date`
- **`AiChatMessage`**:
  - `id: String`, `role: String` (`"user"` or `"assistant"`), `text: String`, `isStreaming: Boolean`, `timestamp: Long`
- **`AutoTagSuggestion`**:
  - `memoryId: String`, `suggestedCategory: String`, `suggestedTags: List<String>`

### Interactive Component & State Mapping

1. **Activating a "While You're At It" Context**:
   - Triggered via `viewModel.activateContextSession(contextQuery)` from either the Universal Input, a Quick Context Pill on `HomeScreen` / `RemindersScreen`, or tapping a trigger badge on any reminder card.
   - Immediately populates `activeContextSession` by matching `Reminder` triggers/locations/people, related `Preference` categories/keywords, and `Fix` tools/topics, plus companion task suggestions.
   - Checking an item in `ContextualTriggerBanner` (upgraded to the interactive checklist) toggles its completion state in Room (`markReminderDone`), updates the checklist progress bar, and allows one-tap saving of AI-suggested companion tasks.
2. **Generating AI Daily Briefing**:
   - Triggered via `viewModel.generateDailyBriefing()`. Calls `aiService.generateDailyBriefing(...)` with a 45s timeout and structured schema, updating `aiBriefingState` to display priority tasks, memory distribution, and cross-memory insights.
3. **Streaming AI Follow-Up Chat**:
   - Triggered via `viewModel.sendFollowUpChatMessage(prompt)`. Uses `Firebase.ai.generativeModel("gemini-3.8-flash").generateContentStream(...)` to stream tokens directly into `streamingChatState`, with a **"Save Reply as Memory"** action on any assistant message.
4. **AI Auto-Tagging & Smart Category Organization**:
   - Triggered automatically on new unstructured inputs or on-demand via `viewModel.autoOrganizeMemories()`. Evaluates entries with default/missing categories or sparse tags, applies Gemini's suggested `category` and `tags`, and persists them to Room (`updateMemoryCategory` + `saveMemoryEntry`).
5. **Proactive AI Errand & Shopping Checklist Generator**:
   - Triggered via `viewModel.generateErrandChecklist(destinationOrActivity)`. Synthesizes saved reminders, food/shopping preferences, and hardware tools needed from active fixes into an interactive checklist session.
