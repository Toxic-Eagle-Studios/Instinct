package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
  entities = [
    ReminderEntity::class,
    PreferenceEntity::class,
    FixEntity::class,
    UnifiedMemoryEntity::class
  ],
  version = 4,
  exportSchema = false
)
@TypeConverters(MemoryTypeConverters::class)
abstract class InstinctDatabase : RoomDatabase() {
  abstract fun reminderDao(): ReminderDao
  abstract fun preferenceDao(): PreferenceDao
  abstract fun fixDao(): FixDao
  abstract fun unifiedMemoryDao(): UnifiedMemoryDao

  /**
   * Alias accessor for the [MemoryEntryDao] (`UnifiedMemoryDao`) that persists [com.example.data.model.MemoryEntry] records.
   */
  fun memoryEntryDao(): MemoryEntryDao = unifiedMemoryDao()

  companion object {
    @Volatile
    private var INSTANCE: InstinctDatabase? = null

    val MIGRATION_3_4 = object : Migration(3, 4) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE reminders ADD COLUMN category TEXT NOT NULL DEFAULT 'Personal'")
        db.execSQL("ALTER TABLE fixes ADD COLUMN category TEXT NOT NULL DEFAULT 'Personal'")
        db.execSQL("UPDATE unified_memories SET category = 'Personal' WHERE category = ''")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_reminders_userId_category ON reminders(userId, category)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_fixes_userId_category ON fixes(userId, category)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_unified_memories_userId_category ON unified_memories(userId, category)")
      }
    }

    fun getDatabase(context: Context): InstinctDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          InstinctDatabase::class.java,
          "instinct_database"
        )
          .addMigrations(MIGRATION_3_4)
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
