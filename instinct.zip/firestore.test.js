const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read reminders", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("reminders").get());
});

test("Authenticated user: cannot read another user's reminders", async () => {
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("reminders").get());
});

test("Authenticated user: can create their own reminder", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("reminders").doc("rem_1").set({
      id: "rem_1",
      userId: ALICE_UID,
      title: "Buy milk",
      triggerActivity: "Going to grocery store",
      relatedPeople: [],
      relatedLocations: ["grocery store"],
      keywords: ["milk", "store"],
      recurrence: "every_time",
      isCompleted: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );
});

test("Authenticated user: can read their own reminders", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await aliceDb.collection("users").doc(ALICE_UID).collection("reminders").doc("rem_1").set({
    id: "rem_1",
    userId: ALICE_UID,
    title: "Buy milk",
    triggerActivity: "Going to grocery store",
    recurrence: "every_time",
    isCompleted: false,
    createdAt: new Date(),
    updatedAt: new Date(),
  });
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("reminders").get()
  );
});

test("Unauthenticated user: cannot read memories", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("memories").get());
});

test("Authenticated user: cannot read another user's memories", async () => {
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("memories").get());
});

test("Authenticated user: can create and read unified memory items across reminder, preference, and fix types", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();

  // 1. Reminder type in shared collection
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("memories").doc("mem_rem_1").set({
      id: "mem_rem_1",
      userId: ALICE_UID,
      type: "reminder",
      title: "Ask Mom about Friday",
      content: "When calling Mom, remind to ask about Friday",
      triggerActivity: "Calling Mom",
      relatedPeople: ["Mom"],
      recurrence: "every_time",
      isCompleted: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );

  // 2. Preference type in shared collection
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("memories").doc("mem_pref_1").set({
      id: "mem_pref_1",
      userId: ALICE_UID,
      type: "preference",
      title: "Oat Milk Cortado",
      content: "Double shot, oat milk, extra hot",
      category: "Coffee & Drinks",
      details: "Two pumps vanilla, no foam",
      tags: ["coffee", "oat milk"],
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );

  // 3. Fix type in shared collection
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("memories").doc("mem_fix_1").set({
      id: "mem_fix_1",
      userId: ALICE_UID,
      type: "fix",
      title: "Spilled grease on cotton shirt",
      content: "Baking soda and dish soap pre-treatment",
      problemSummary: "Spilled grease on cotton shirt",
      whatHappened: "Grease saturated cotton fibers",
      bestFix: "Apply baking soda, then dawn dish soap",
      steps: ["Apply baking soda", "Let sit 10 min", "Rub dish soap"],
      toolsNeeded: ["Baking soda", "Dish soap"],
      isVerifiedWorking: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );

  // 4. Query all items together in the single shared collection
  const snapshot = await aliceDb.collection("users").doc(ALICE_UID).collection("memories").get();
  assertSucceeds(Promise.resolve(snapshot));
});
